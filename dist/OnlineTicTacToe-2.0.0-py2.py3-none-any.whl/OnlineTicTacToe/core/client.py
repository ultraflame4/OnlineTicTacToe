

class BaseClient:
    """
    Base Class for Multiplayer Client & offline client
    """
    pass